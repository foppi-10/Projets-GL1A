#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    Player=new QMediaPlayer();


    ui->pushButton_Play_Pause->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    ui->pushButton_Stop->setIcon(style()->standardIcon(QStyle::SP_MediaStop));
    ui->pushButton_Seek_Forward->setIcon(style()->standardIcon(QStyle::SP_MediaSeekForward));
    ui->pushButton_Seek_Backward->setIcon(style()->standardIcon(QStyle::SP_MediaSeekBackward));
    ui->pushButton_Volume->setIcon(style()->standardIcon(QStyle::SP_MediaVolume));

    ui->horizontalSlider_Volume->setMinimum(0);
    ui->horizontalSlider_Volume->setMaximum(100);
    ui->horizontalSlider_Volume->setValue(30);

    Player->setVolume(ui->horizontalSlider_Volume->value());

    connect(Player,&QMediaPlayer::durationChanged,this,&MainWindow::durationChanged);
    connect(Player,&QMediaPlayer::positionChanged,this,&MainWindow::positionChanged);

    ui->horizontalSlider_Duration->setRange(0,Player->duration() / 1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::durationChanged(qint64 duration)
{
    mDuration=duration/1000;
    ui->horizontalSlider_Duration->setMaximum(mDuration);

}
void MainWindow::positionChanged(qint64 duration)
{
    if(ui->horizontalSlider_Duration->isSliderDown()){
        ui->horizontalSlider_Duration->setValue(duration/1000);
    }
    updateDuration(duration/1000);

}


void MainWindow::on_horizontalSlider_Duration_valueChanged(int value)
{
    Player->setPosition(value * 1000);
}

void MainWindow::on_pushButton_Play_Pause_clicked()
{
    if(IS_Pause==true){
        IS_Pause==false;
        ui->pushButton_Play_Pause->setIcon(style()->standardIcon(QStyle::SP_MediaPause));
        Player->play();
    }else{
        IS_Pause==true;
        ui->pushButton_Play_Pause->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
        Player->pause();
    }
}

void MainWindow::on_pushButton_Stop_clicked()
{
    Player->stop();
}

void MainWindow::on_pushButton_Volume_clicked()
{
    if(IS_Muted==false){
        IS_Muted==true;
        ui->pushButton_Volume->setIcon(style()->standardIcon(QStyle::SP_MediaVolumeMuted));
        Player->setMuted(true);
    }else{
        IS_Muted==false;
        ui->pushButton_Volume->setIcon(style()->standardIcon(QStyle::SP_MediaVolume));
        Player->setMuted(false);
    }
}

void MainWindow::on_horizontalSlider_Volume_valueChanged(int value)
{
    Player->setVolume(value);

}

void MainWindow::on_actionOpen_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Sélectionner un fichier vidéo"), "", tr("Fichiers MP4 (*.mp4)"));

      if (!fileName.isEmpty()) {
          Player->setMedia(QUrl::fromLocalFile(fileName));
          Player->play();  // Lance la lecture automatiquement
      }

    Video = new QVideoWidget();


    Video->setGeometry(5,5,ui->groupBox_Video->width()-10,ui->groupBox_Video->height()-10);
    Video->setParent(ui->groupBox_Video);

    Player->setVideoOutput(Video);

    Player->setMedia(QUrl::fromLocalFile(fileName));

    Video->setVisible(true);
    Video->show();
}

void MainWindow::on_pushButton_Seek_Backward_clicked()
{
    ui->horizontalSlider_Duration->setValue(ui->horizontalSlider_Duration->value()-10);
    Player->setPosition(ui->horizontalSlider_Duration->value() * 1000);
}

void MainWindow::on_pushButton_Seek_Forward_clicked()
{
    ui->horizontalSlider_Duration->setValue(ui->horizontalSlider_Duration->value()+10);
}

void MainWindow::updateDuration(qint64 Duration)
{
    if (Duration || mDuration)
        {

            QTime CurrentTime(
                (Duration / 3600) % 60,
                (Duration / 60) % 60,
                Duration % 60,
                (Duration * 1000) % 1000
            );


            QTime TotalTime(
                (mDuration / 3600) % 60,
                (mDuration / 60) % 60,
                mDuration % 60,
                (mDuration * 1000) % 1000
            );


            QString timeFormat = (mDuration > 3600) ? "hh:mm:ss" : "mm:ss";

            ui->label_current_Time->setText(CurrentTime.toString(timeFormat));
            ui->label_Total_Time->setText(TotalTime.toString(timeFormat));
    }
}
